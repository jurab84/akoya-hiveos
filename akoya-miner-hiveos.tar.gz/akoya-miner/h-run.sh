#!/usr/bin/env bash
# Hive OS run script for Akoya Miner (Pearl / PEARL)

INSTALL_DIR="/opt/akoya-miner"
CONFIG_FILE="/etc/akoya-miner/config.json"
STATS_FILE="/tmp/akoya-miner-stats.json"
DOWNLOAD_BASE="https://get.akoyapool.com/releases"

# ── Parse Hive OS Flight Sheet variables ─────────────────────────────────────
# CUSTOM_TEMPLATE = "WALLET.WORKER" or just "WALLET"
# CUSTOM_URL      = pool host:port  (e.g. pool.akoyapool.com:3333)
# CUSTOM_PASS     = password (not used by this pool, kept for compat)

WALLET="${CUSTOM_TEMPLATE%%.*}"          # everything before first dot
WORKER="${CUSTOM_TEMPLATE#*.}"           # everything after first dot
[[ "$WORKER" == "$WALLET" ]] && WORKER="${WORKER_NAME:-worker1}"

POOL_URL="${CUSTOM_URL:-pool.akoyapool.com:3333}"

# ── Install / update binary if missing or outdated ───────────────────────────
install_or_update() {
    # Resolve latest version
    local VERSION
    VERSION=$(curl -fsSL "${DOWNLOAD_BASE}/latest.txt" 2>/dev/null | tr -d '[:space:]') || VERSION=""
    [[ -z "$VERSION" ]] && VERSION="1.0.0"

    local INSTALLED_VERSION=""
    [[ -f "$INSTALL_DIR/VERSION" ]] && INSTALLED_VERSION=$(cat "$INSTALL_DIR/VERSION")

    if [[ "$INSTALLED_VERSION" == "$VERSION" && -x "$INSTALL_DIR/akoya-miner.bin" ]]; then
        echo "[akoya] Binary up to date: v$VERSION"
        return 0
    fi

    echo "[akoya] Downloading v$VERSION..."
    local TARBALL="akoya-miner-${VERSION}-portable.tar.gz"
    local URL="${DOWNLOAD_BASE}/${VERSION}/${TARBALL}"

    curl -fSL --progress-bar -o "/tmp/$TARBALL" "$URL" || {
        echo "[akoya] ERROR: Download failed from $URL"
        exit 1
    }

    mkdir -p "$INSTALL_DIR"
    tar -xzf "/tmp/$TARBALL" -C "$INSTALL_DIR" --strip-components=1
    rm -f "/tmp/$TARBALL"
    chmod +x "$INSTALL_DIR/akoya-miner.bin" 2>/dev/null || true
    echo "[akoya] Installed to $INSTALL_DIR"
}

# ── Write config ──────────────────────────────────────────────────────────────
write_config() {
    mkdir -p "$(dirname "$CONFIG_FILE")"
    cat > "$CONFIG_FILE" << CONF
{
  "pool": {
    "url": "${POOL_URL}",
    "wallet": "${WALLET}",
    "worker": "${WORKER}"
  },
  "logging": {
    "level": "info"
  },
  "devices": "all"
}
CONF
    echo "[akoya] Config written — wallet: ${WALLET}, worker: ${WORKER}, pool: ${POOL_URL}"
}

# ── Select GEMM kernel ────────────────────────────────────────────────────────
select_kernel() {
    local LIB_DIR="$INSTALL_DIR/lib"
    local SYMLINK="$LIB_DIR/libpearl_gemm_capi.so"
    [[ -L "$SYMLINK" ]] && return 0
    local CC
    CC=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader,nounits 2>/dev/null | head -1)
    local MAJOR="${CC%%.*}"
    if [[ "$MAJOR" == "9" ]] && [[ -f "$LIB_DIR/libpearl_gemm_capi_h100.so" ]]; then
        ln -sf libpearl_gemm_capi_h100.so "$SYMLINK"
        echo "[akoya] Using H100-optimised kernel"
    else
        ln -sf libpearl_gemm_capi_portable.so "$SYMLINK"
        echo "[akoya] Using portable kernel (RTX 30/40/50)"
    fi
}

# ── Main ──────────────────────────────────────────────────────────────────────
install_or_update
write_config
select_kernel

export LD_LIBRARY_PATH="${INSTALL_DIR}/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export AKOYA_HIVEOS_STATS_PATH="$STATS_FILE"

exec "$INSTALL_DIR/akoya-miner.bin" --config "$CONFIG_FILE"
