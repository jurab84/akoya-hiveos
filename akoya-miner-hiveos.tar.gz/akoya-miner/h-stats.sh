#!/usr/bin/env bash
# Hive OS stats script for Akoya Miner
# Converts /tmp/akoya-miner-stats.json → Hive OS JSON format

STATS_FILE="/tmp/akoya-miner-stats.json"

# If no stats file yet — return zeroed stub (miner still starting)
if [[ ! -f "$STATS_FILE" ]]; then
    GPU_COUNT=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | wc -l)
    HS=$(printf '0,'%.0s $(seq 1 $GPU_COUNT) | sed 's/,$//')
    TEMPS=$(printf '0,'%.0s $(seq 1 $GPU_COUNT) | sed 's/,$//')
    FANS=$(printf '0,'%.0s $(seq 1 $GPU_COUNT) | sed 's/,$//')
    echo "{\"hs\":[$HS],\"hs_units\":\"gh\",\"temp\":[$TEMPS],\"fan\":[$FANS],\"uptime\":0,\"ver\":\"0\",\"ar\":[0,0]}"
    exit 0
fi

# Parse the akoya stats JSON and reformat for Hive OS
python3 - <<'PYEOF'
import json, sys, os, time

STATS = "/tmp/akoya-miner-stats.json"
try:
    with open(STATS) as f:
        s = json.load(f)
except Exception as e:
    print('{}', file=sys.stderr)
    sys.exit(0)

gpus    = s.get("gpus", [])
shares  = s.get("shares", {})
uptime  = int(s.get("uptime_seconds", 0))

# Each GPU exports hashrate in GH/s
hs     = [g.get("hashrate_gh", 0.0)  for g in gpus]
temps  = [g.get("temp_c", 0)         for g in gpus]
fans   = [g.get("fan_pct", 0)        for g in gpus]
power  = [g.get("power_w", 0)        for g in gpus]

accepted = shares.get("accepted", 0)
rejected = shares.get("rejected", 0)

# Try to get miner version
ver = s.get("version", "")
if not ver:
    try:
        ver = open("/opt/akoya-miner/VERSION").read().strip()
    except Exception:
        ver = "?"

result = {
    "hs":       hs,
    "hs_units": "gh",
    "temp":     temps,
    "fan":      fans,
    "power":    power,
    "uptime":   uptime,
    "ver":      ver,
    "ar":       [accepted, rejected],
}

print(json.dumps(result))
PYEOF
